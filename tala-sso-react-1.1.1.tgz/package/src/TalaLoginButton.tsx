import React, { useState, useEffect, useRef } from 'react';
import { Loader2 } from 'lucide-react';

interface TalaLoginButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  loginUrl: string;
  onSuccess: (code: string, state: string) => void | Promise<void>;
  onLoginError?: (error: string) => void;
  onStateGenerated?: (state: string) => void;
  /** Origin the callback page is served from. Defaults to this page's origin. */
  allowedOrigin?: string;
  className?: string;
  children?: React.ReactNode;
}

export const TalaLoginButton: React.FC<TalaLoginButtonProps> = ({
  loginUrl,
  onSuccess,
  onLoginError,
  onStateGenerated,
  allowedOrigin,
  className = '',
  children,
  ...props
}) => {
  const [isLoading, setIsLoading] = useState(false);
  // The popup we opened and the state we were given; messages must match both.
  const popupRef = useRef<Window | null>(null);
  const expectedStateRef = useRef<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Close the popup and stop polling if the button unmounts mid-login.
  useEffect(
    () => () => {
      if (timerRef.current) clearInterval(timerRef.current);
      popupRef.current?.close();
    },
    []
  );

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      const origin = allowedOrigin ?? window.location.origin;
      if (event.origin !== origin) return;
      if (!popupRef.current || event.source !== popupRef.current) return;

      if (event.data?.type === 'TALA_AUTH_SUCCESS') {
        if (!expectedStateRef.current || event.data.state !== expectedStateRef.current) {
          setIsLoading(false);
          if (onLoginError) onLoginError('Sign-in session mismatch. Please try again.');
          return;
        }
        expectedStateRef.current = null; // single use
        setIsLoading(true); // Keep loading while parent app exchanges code
        Promise.resolve(onSuccess(event.data.code, event.data.state))
          .catch((err) => {
            if (onLoginError) onLoginError(err instanceof Error ? err.message : String(err));
          })
          .finally(() => {
            setIsLoading(false);
          });
      } else if (event.data?.type === 'TALA_AUTH_ERROR') {
        setIsLoading(false);
        if (onLoginError) onLoginError(event.data.error || 'Authentication failed');
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onSuccess, onLoginError, allowedOrigin]);

  const handleLogin = async () => {
    setIsLoading(true);

    // Open the popup synchronously, inside the click, so popup blockers allow it.
    // It is pointed at the authorize URL once the backend has produced it.
    const width = 500;
    const height = 650;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;
    const popup = window.open(
      'about:blank',
      'tala_login',
      `width=${width},height=${height},left=${left},top=${top},toolbar=0,scrollbars=1,status=1,resizable=1,location=1,menuBar=0`
    );
    popupRef.current = popup;

    try {
      if (!popup) throw new Error('Popup was blocked by the browser. Please allow popups for this site.');

      // We expect the parent app to provide the loginUrl which hits the backend redirect endpoint
      const response = await fetch(loginUrl);
      if (!response.ok) throw new Error('Failed to initialize login');

      const data = await response.json();
      if (!data.state || !data.authorize_url) throw new Error('Failed to initialize login');
      expectedStateRef.current = data.state;

      if (onStateGenerated) {
        onStateGenerated(data.state);
      }

      popup.location.href = data.authorize_url;

      // Reset loading state if the user closes the popup
      const timer = setInterval(() => {
        if (popup.closed) {
          clearInterval(timer);
          setIsLoading(false);
        }
      }, 500);
      timerRef.current = timer;
    } catch (err: any) {
      popup?.close();
      popupRef.current = null;
      expectedStateRef.current = null;
      setIsLoading(false);
      if (onLoginError) onLoginError(err.message || 'Failed to open login window');
    }
  };

  return (
    <button 
      type="button"
      onClick={handleLogin} 
      disabled={isLoading || props.disabled}
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: '0.375rem',
        fontSize: '0.875rem',
        fontWeight: 500,
        transition: 'background-color 0.2s',
        backgroundColor: 'transparent',
        color: '#374151',
        height: '2.5rem',
        padding: '0.5rem 1rem',
        border: '1px solid #d1d5db',
        cursor: (isLoading || props.disabled) ? 'not-allowed' : 'pointer',
        opacity: (isLoading || props.disabled) ? 0.5 : 1,
        ...props.style
      }}
      {...props}
    >
      {isLoading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" style={{ marginRight: '0.5rem', animation: 'spin 1s linear infinite' }} />
          Loading...
        </>
      ) : (
        children || 'Sign in with TALA'
      )}
    </button>
  );
};
