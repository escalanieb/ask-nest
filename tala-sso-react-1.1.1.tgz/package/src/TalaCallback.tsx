import React, { useEffect } from 'react';

interface TalaCallbackProps {
  /** Origin of the window that opened this popup. Defaults to this page's origin. */
  targetOrigin?: string;
}

export const TalaCallback: React.FC<TalaCallbackProps> = ({ targetOrigin }) => {
  useEffect(() => {
    // We are inside the popup window. Read the URL parameters.
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const state = urlParams.get('state');
    const error = urlParams.get('error');
    const errorDescription = urlParams.get('error_description');
    // The callback page is served by the same app that opened the popup, so only
    // that origin may receive the authorization code.
    const origin = targetOrigin ?? window.location.origin;

    if (error) {
      // Send error to parent window
      if (window.opener) {
        window.opener.postMessage(
          {
            type: 'TALA_AUTH_ERROR',
            error: errorDescription || error,
          },
          origin
        );
      }
      window.close();
      return;
    }

    if (code && state) {
      // Send code and state to parent window
      if (window.opener) {
        window.opener.postMessage(
          {
            type: 'TALA_AUTH_SUCCESS',
            code,
            state,
          },
          origin
        );
      }
      window.close();
    }
  }, [targetOrigin]);

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', fontFamily: 'sans-serif' }}>
      <p>Completing authentication...</p>
    </div>
  );
};
