import React, { useEffect } from 'react';

export const TalaCallback: React.FC = () => {
  useEffect(() => {
    // We are inside the popup window. Read the URL parameters.
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const state = urlParams.get('state');
    const error = urlParams.get('error');
    const errorDescription = urlParams.get('error_description');

    if (error) {
      // Send error to parent window
      if (window.opener) {
        window.opener.postMessage(
          { 
            type: 'TALA_AUTH_ERROR', 
            error: errorDescription || error 
          }, 
          '*' // In production, we could restrict this to the known frontend URL
        );
      }
      window.close();
      return;
    }

    if (code && state) {
      // Send code and state to parent window
      if (window.opener) {
        window.opener.postMessage(
          { 
            type: 'TALA_AUTH_SUCCESS', 
            code, 
            state 
          }, 
          '*'
        );
      }
      window.close();
    }
  }, []);

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', fontFamily: 'sans-serif' }}>
      <p>Completing authentication...</p>
    </div>
  );
};
