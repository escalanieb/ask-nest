import React, { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';

interface TalaLoginButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  loginUrl: string;
  onSuccess: (code: string, state: string) => void | Promise<void>;
  onLoginError?: (error: string) => void;
  onStateGenerated?: (state: string) => void;
  className?: string;
  children?: React.ReactNode;
}

export const TalaLoginButton: React.FC<TalaLoginButtonProps> = ({
  loginUrl,
  onSuccess,
  onLoginError,
  onStateGenerated,
  className = '',
  children,
  ...props
}) => {
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      // Security: we should ideally check event.origin, but for this generic SDK,
      // we trust the developer to handle origin checks if needed, or we just rely on the specific data structure.
      if (event.data?.type === 'TALA_AUTH_SUCCESS') {
        setIsLoading(true); // Keep loading while parent app exchanges code
        Promise.resolve(onSuccess(event.data.code, event.data.state))
          .catch((err) => {
            if (onLoginError) onLoginError(err instanceof Error ? err.message : String(err));
          })
          .finally(() => {
            setIsLoading(false);
          });
      } else if (event.data?.type === 'TALA_AUTH_ERROR') {
        setIsLoading(false);
        if (onLoginError) onLoginError(event.data.error || 'Authentication failed');
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onSuccess, onLoginError]);

  const handleLogin = async () => {
    setIsLoading(true);
    
    try {
      // We expect the parent app to provide the loginUrl which hits the backend redirect endpoint
      const response = await fetch(loginUrl);
      if (!response.ok) throw new Error('Failed to initialize login');
      
      const data = await response.json();
      
      if (onStateGenerated && data.state) {
        onStateGenerated(data.state);
      }
      
      const width = 500;
      const height = 650;
      const left = window.screenX + (window.outerWidth - width) / 2;
      const top = window.screenY + (window.outerHeight - height) / 2;

      const popup = window.open(
        data.authorize_url,
        'tala_login',
        `width=${width},height=${height},left=${left},top=${top},toolbar=0,scrollbars=1,status=1,resizable=1,location=1,menuBar=0`
      );

      if (!popup) {
        throw new Error('Popup was blocked by the browser. Please allow popups for this site.');
      }

      // Check if popup closed prematurely
      const timer = setInterval(() => {
        if (popup.closed) {
          clearInterval(timer);
          setIsLoading(false); // Reset loading state if user closed popup
        }
      }, 500);

    } catch (err: any) {
      setIsLoading(false);
      if (onLoginError) onLoginError(err.message || 'Failed to open login window');
    }
  };

  return (
    <button 
      onClick={handleLogin} 
      disabled={isLoading || props.disabled}
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: '0.375rem',
        fontSize: '0.875rem',
        fontWeight: 500,
        transition: 'background-color 0.2s',
        backgroundColor: 'transparent',
        color: '#374151',
        height: '2.5rem',
        padding: '0.5rem 1rem',
        border: '1px solid #d1d5db',
        cursor: (isLoading || props.disabled) ? 'not-allowed' : 'pointer',
        opacity: (isLoading || props.disabled) ? 0.5 : 1,
        ...props.style
      }}
      {...props}
    >
      {isLoading ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" style={{ marginRight: '0.5rem', animation: 'spin 1s linear infinite' }} />
          Loading...
        </>
      ) : (
        children || 'Sign in with TALA'
      )}
    </button>
  );
};
